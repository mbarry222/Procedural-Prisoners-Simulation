import unittest
import strategies
from strategies import tit_for_two_tats


class TestTitForTwoTats(unittest.TestCase):

    def test_start_with_cooperate(self):
        # When starting the game, the player should cooperate ('c').
        strategies.reset()
        result = tit_for_two_tats(None)
        self.assertEqual(result, 'c')

    def test_betray_after_opponent_betrays(self):
        # If the opponent betrays ('b') in the previous round,
        # but it was the first time,
        # the player should cooperate ('c') in the current round.
        strategies.reset()
        result = tit_for_two_tats('b')
        self.assertEqual(result, 'c')

    def test_cooperate_after_opponent_cooperates(self):
        # If the opponent cooperates ('c') in the previous round,
        # the player should cooperate ('c') in the current round.
        strategies.reset()
        result = tit_for_two_tats('c')
        self.assertEqual(result, 'c')

    def test_betray_after_opponent_betrays_twice(self):
        # If the opponent betrays ('b') in the previous round,
        # the player should betray ('b') in the current round.
        strategies.reset()
        result = tit_for_two_tats('b')
        self.assertEqual(result, 'c')
        result = tit_for_two_tats('b')
        self.assertEqual(result, 'b')

if __name__ == "__main__":
    unittest.main()
