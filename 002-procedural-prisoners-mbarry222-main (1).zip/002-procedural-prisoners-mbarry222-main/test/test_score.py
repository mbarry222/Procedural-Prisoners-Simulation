import unittest
from strategies import score


class TestScore(unittest.TestCase):

    def test_both_cooperate(self):
        # If both player and computer cooperate, both should get 1 point.
        player_score, computer_score = score('c', 'c')
        self.assertEqual(player_score, 1)
        self.assertEqual(computer_score, 1)

    def test_player_cooperates_computer_betrays(self):
        # If the player cooperates and the computer betrays,
        # the player should get 3 points, and the computer should get 0 points.
        player_score, computer_score = score('c', 'b')
        self.assertEqual(player_score, 3)
        self.assertEqual(computer_score, 0)

    def test_player_betrays_computer_cooperates(self):
        # If the player betrays and the computer cooperates,
        # the player should get 0 points, and the computer should get 3 points.
        player_score, computer_score = score('b', 'c')
        self.assertEqual(player_score, 0)
        self.assertEqual(computer_score, 3)

    def test_both_betray(self):
        # If both player and computer betray, both should get 2 points.
        player_score, computer_score = score('b', 'b')
        self.assertEqual(player_score, 2)
        self.assertEqual(computer_score, 2)

    def test_invalid_choices(self):
        # If the choices are invalid, both should get 2 points by default.
        player_score, computer_score = score('invalid', 'invalid')
        self.assertEqual(player_score, 2)
        self.assertEqual(computer_score, 2)

if __name__ == "__main__":
    unittest.main()
