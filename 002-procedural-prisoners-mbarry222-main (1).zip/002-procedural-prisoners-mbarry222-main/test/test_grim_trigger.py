import unittest

import strategies
from strategies import grim_trigger


class TestGrimTrigger(unittest.TestCase):

    def test_start_with_cooperate(self):
        # When starting the game, the player should cooperate ('c').
        strategies.reset()
        result = grim_trigger(None)
        self.assertEqual(result, 'c')

    def test_cooperate_after_opponent_cooperates(self):
        # If the opponent cooperates ('c') in the previous round,
        # the player should cooperate ('c') in the current round.
        strategies.reset()
        result = grim_trigger('c')
        self.assertEqual(result, 'c')

    def test_betray_after_opponent_betrays(self):
        # If the opponent betrays ('b') in the previous round,
        # the player should betray ('b') in the current round.
        strategies.reset()
        result = grim_trigger('b')
        self.assertEqual(result, 'b')

    def test_cooperate_after_opponent_unknown(self):
        # If the opponent's move is unknown (None), the player
        # should cooperate ('c') by default.
        strategies.reset()
        result = grim_trigger(None)
        self.assertEqual(result, 'c')

    def test_betray_after_opponent_betray(self):
        # If the opponent betrays ('b') in the previous round,
        # the player should betray ('b') indefinitely.
        strategies.reset()
        result = grim_trigger('b')
        self.assertEqual(result, 'b')
        result = grim_trigger('c')
        self.assertEqual(result, 'b')


if __name__ == "__main__":
    unittest.main()
