# Procedural Prisoner's Dilemma

In this homework assignment, you will implement a Python program that simulates the classic game known as the "Prisoner's Dilemma." The Prisoner's Dilemma is a game theory scenario where two players can either cooperate or betray each other, leading to different outcomes and payoffs. We're implementing this in a procedural programming style. For a later assignment, we will discuss how we might translate this to an OOP design.

## Objectives:

1. Implement three distinct strategies: Tit-for-Tat, Grim Trigger, and Tit-for-Two-Tats.
2. Randomly select one strategy for the computer to simulate playing the game.
3. Prompt the player for 'cooperate' or 'betray' input.
4. Display the computer's chosen strategy to the player after the game ends.
5. Create a scoring system based on game outcomes.
6. Implement a game loop allowing the player to decide whether to continue.
7. Display final scores, chosen strategy, and declare the winner.
8. Include comments and documentation in the code.
9. Submit two source files to GitHub and follow best coding practices.

**The Dilemma**

> Two members of a criminal gang are arrested and imprisoned. Each prisoner is in solitary confinement with no means of speaking to or exchanging messages with the other. The police admit they don't have enough evidence to convict the pair on the principal charge. They plan to sentence both to a year in prison on a lesser charge. Simultaneously, the police offer each prisoner a Faustian bargain. If he testifies against his partner, he will go free while the partner will get three years in prison on the main charge. Oh, yes, there is a catch ... If both prisoners testify against each other, both will be sentenced to two years in jail. The prisoners are given a little time to think this over, but in no case may either learn what the other has decided until he has irrevocably made his decision. Each is informed that the other prisoner is being offered the very same deal. Each prisoner is concerned only with his own welfare—with minimizing his own prison sentence.

- William Poundstone, _Prisoner's Dillemma_, 1993

## Iterated Prisoner's Dilemma

The prisoner's dilemma has applications in many real-world circumstances, from setting prices competitively in business to getting matches on Tinder. You may even find yourself on a game show playing this out for cash prizes, where [you may use your knowledge of the dilemma to change the rules a bit](https://www.youtube.com/watch?v=S0qjK3TWZE8)!

In most real-world circumstances, however, the match is not a single event but one of a series of interactions. Betray someone once, and they just may remember it the next time that you interact and choose to betray you in retaliation. Treat someone fairly, and they may be more inclined to cooperate with you. 

To model this more realistic behavior, most researchers study what's known as the **iterated prisoner's dilemma**. In this version, rather than making the choice once, the two players will have many chances to cooperate or betray. The players may alter their strategy based on the opponent's behavior or may just keep doing the same thing over and over again. And the end of all the matches, whoever has the highest score wins. 

## Assignment Requirements

Implement three different strategies that the computer can use in the Prisoner's Dilemma game. 

1. Tit-for-Tat:
    - This [strategy](https://en.wikipedia.org/wiki/Tit_for_tat) starts with cooperation and then mimics the opponent's previous move. If the opponent cooperated in the previous round, it cooperates; if the opponent betrayed, it betrays. It reciprocates the opponent's behavior. 
2. Grim Trigger:
   - The [Grim Trigger](https://en.wikipedia.org/wiki/Grim_trigger) strategy starts with cooperation and continues to cooperate until the opponent betrays. Once the opponent betrays, the grim trigger strategy holds a grudge and always chooses to betray for the rest of the game, never forgiving the betrayal.
3. Tit-for-Two-Tats:
   - [Tit-for-two-tats](https://en.wikipedia.org/wiki/Tit_for_tat#Tit_for_two_tats) starts with cooperation and mimics the opponent's previous move. However, it requires two consecutive betrayals from the opponent to switch to betrayal. 

Write a Python program with the following features:

1. The program should randomly select one of the three strategies to use against the player for an entire game of iterated prisoner's dilemma. Do not have it randomly select a new strategy each round.
2. It should prompt the player for their choice, which can be either "cooperate" or "betray." The user will type either 'c' or 'b' to input their choice.
3. The program should display the computer's choice (selected strategy) to the player. And the resulting change in score. The score is tallied current number of years that have been added to their sentence. 
4. After each round, the program should ask the player if they want to play again. If the player chooses to continue, another round should be played with a random strategy selection. If the player chooses to stop, the game should end.

Keep track of the score for both the player and the computer throughout the game. Assign appropriate scores based on the outcomes of each round. Put the code for this into the `score()` function in the stategies.py file. The number of "years" added to the sentence must fit the following:

| Player Choice | Computer Choice | Player Score | Computer Score |
|---------------|-----------------|--------------|----------------|
| 'c'           | 'c'             | 1            | 1              |
| 'c'           | 'b'             | 3            | 0              |
| 'b'           | 'c'             | 0            | 3              |
| 'b'           | 'b'             | 2            | 2              |

The game should continue until the player decides to stop playing. Upon ending the game, the program should reveal the final scores and which random strategy was selected for that game. It should also indicate the winner (whoever has the lowest number of additional years to serve, i.e., the fewest points).

Example Output:

```terminal

Welcome to the Prisoner's Dilemma Game!

Round 1:
Will you ([c]ooperate or [b]etray)?:c
You chose: cooperate
Computer chose: cooperate

Would you like to play again? [y/n]:y

Round 2:
Will you ([c]ooperate or [b]etray)?:b
You chose: betray
Computer chose: cooperate

Would you like to play again? [y/n]:y

Round 3:
Will you ([c]ooperate or [b]etray)?:c
You chose: cooperate
Computer chose: betray

Would you like to play again? [y/n]:y

Round 4:
Will you ([c]ooperate or [b]etray)?:c
You chose: cooperate
Computer chose: cooperate

Would you like to play again? [y/n]:n

Final Scores:
Player: 5
Computer: 5

It was a tie game
The computer used Tit-for-Tat
Thanks for playing!
```

## Submission Guidelines:

Please commit/push your Python program in the two source files (prisoners.py and strategies.py) along with any necessary comments and documentation. Ensure that your program is well-documented and follows best coding practices.

**Unit Tests**
Test files are provided for the four functions that you have been asked to write. Empty "skeleton functions" have been provided in the strategies.py file for you to complete. Do not change the names or parameters of the functions - these are critical for the tests to let you know if a function working correctly. A "skeleton function" for a `reset()` function has also been provided. The purpose of this is to reset any global variables to their starting positions during testing - the grim trigger and tit-for-two-tats functions depend on a sequence of interactions, so the tests for those functions call the reset function to make sure that the sequence is correct. 

Grading Criteria:
Please refer to Canvas for the grading rubric for this assignment. 