import random

def reset():
    global grim_trigger_triggered
    grim_trigger_triggered = False

def tit_for_tat(last_choice):
    return last_choice if last_choice in ['c', 'b'] else 'c'

def tit_for_two_tats(history):
    if len(history) >= 2 and history[-1] == 'b' and history[-2] == 'b':
        return 'b'
    else:
        return 'c'

def grim_trigger(last_choice):
    global grim_trigger_triggered
    if last_choice == 'b':
        grim_trigger_triggered = True
    return 'b' if grim_trigger_triggered else 'c'

def score(player_choice, computer_choice):
    scoring = {('c', 'c'): (1, 1), ('c', 'b'): (3, 0), ('b', 'c'): (0, 3), ('b', 'b'): (2, 2)}
    return scoring.get((player_choice, computer_choice), (0, 0))

if __name__ == "__main__":
    grim_trigger_triggered = False
    player_choices = ['c', 'b', 'c']  # Simulated player choices
    history = []  # To track all player choices for strategies requiring history

    print("Welcome to Prisoner's Dilemma. Simulated choices: c to collude, or b to betray.")
    rounds = 3  # Set the number of rounds
    total_player_score, total_computer_score = 0, 0

    for current_round in range(1, rounds + 1):
        reset()
        print(f"\nRound {current_round}")

        player_choice = player_choices[current_round - 1]
        history.append(player_choice)  # Update history with player's choice

        if current_round == 1:
            computer_choice = tit_for_tat(player_choice)
        elif current_round == 2:
            computer_choice = tit_for_two_tats(history)
        else:
            computer_choice = grim_trigger(player_choice)

        player_score, computer_score = score(player_choice, computer_choice)
        total_player_score += player_score
        total_computer_score += computer_score
        print(f"Player choice: {player_choice}, Computer choice: {computer_choice}")
        print(f"Round score - Player: {player_score}, Computer: {computer_score}")

    print(f"\nFinal Score - Player: {total_player_score}, Computer: {total_computer_score}")
    print("Thanks for playing!")

