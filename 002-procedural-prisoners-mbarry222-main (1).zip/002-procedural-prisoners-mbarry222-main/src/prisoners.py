import strategies
import random

def main():
    player_score = 0
    computer_score = 0
    round_number = 1
    player_choices = []
    computer_strategy = random.choice([strategies.tit_for_tat,
                                       strategies.grim_trigger,
                                       strategies.tit_for_two_tats])

    strategies.reset()  # resets state

    print("Welcome to the Prisoner's Dilemma Game!")

    while True:
        print(f"\nRound {round_number}:")
        player_choice = input("Will you ([c]ooperate or [b]etray)?: ")

        # takes input
        if player_choice not in ['c', 'b']:
            print("Invalid input. Please enter 'c' for cooperate or 'b' for betray.")
            continue

        if computer_strategy == strategies.tit_for_two_tats:
            if len(player_choices) >= 2:
                computer_choice = computer_strategy(player_choices[-2:])
            else:
                computer_choice = computer_strategy([])
        else:
            computer_choice = computer_strategy(player_choices[-1] if player_choices else None)

        # Updates player and computer scores
        p_score, c_score = strategies.score(player_choice, computer_choice)
        player_score += p_score
        computer_score += c_score
        player_choices.append(player_choice)

        # Display choices and current scores
        print(f"You chose to {'cooperate' if player_choice == 'c' else 'betray'}.")
        print(f"The computer chose to {'cooperate' if computer_choice == 'c' else 'betray'}.")
        print(f"Scores - You: {player_score}, Computer: {computer_score}")

        # Ask if the player wants to continue
        continue_playing = input("Would you like to play again? (y/n): ")
        if continue_playing.lower() != 'y':
            break

        round_number += 1

    # Display final scores and the selected strategy
    strategy_name = {strategies.tit_for_tat: "Tit-for-Tat",
                     strategies.grim_trigger: "Grim Trigger",
                     strategies.tit_for_two_tats: "Tit-for-Two-Tats"}.get(computer_strategy, "Unknown Strategy")

    print(f"\nFinal Scores:\nYou: {player_score}\nComputer: {computer_score}")
    print(f"The computer used the {strategy_name} strategy.")
    print("Thanks for playing!")


if __name__ == "__main__":
    main()
